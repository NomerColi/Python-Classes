""" Racing Game

Written by: Omar Juarez, Yunjae Cho
Date: Fall 2024

"""
from vehicle import Vehicle
from car import Car
from motorcycle import Motorcycle
from truck import Truck
from random import randint
import check_input

def main():
    pass

main()